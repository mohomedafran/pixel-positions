<div>
    <div class="bg-white/10 my-10 h-px w-full"></div>
</div>
<?php /**PATH C:\Users\frmaf\Documents\Laravel learning\laracasts\pixel-positions\resources\views/components/forms/divider.blade.php ENDPATH**/ ?>