<h1 class="font-bold text-center text-4xl mb-8">{{ $slot }}</h1>
